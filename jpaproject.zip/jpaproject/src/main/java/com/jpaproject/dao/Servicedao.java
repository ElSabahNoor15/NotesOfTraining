package com.jpaproject.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.Session;

import com.jpaproject.model.Booking;
import com.jpaproject.model.Flight;
import com.jpaproject.model.Place;

public class Servicedao {
	public boolean addPlace(Place place)
	
	{
		boolean result=false;
		try{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("puuu");
		EntityManager em=emf.createEntityManager();
		em.getTransaction().begin();
		em.persist(place);
		em.getTransaction().commit();
		result=true;
		}
		catch(Exception e){
			System.out.println("ERROR" +e);
		}
		return result;
		}
	
	
	public Place getPlace(Place place){
		Place p=null;
		try{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("puu");
		EntityManager em=emf.createEntityManager();
		p=em.find(Place.class,place.getPlaceid());
		
	}
		
	catch(Exception e){
		System.out.println("ERROR" +e);
	
	}
		return p;
}
	
	
		public boolean addFlight(Flight flight){
			
			boolean result=false;
		try {
			EntityManagerFactory emf=Persistence.createEntityManagerFactory("puuu");
			EntityManager em=emf.createEntityManager();
			em.getTransaction().begin();
			em.persist(flight);
			em.getTransaction().commit();
			result=true;
			em.close();
			
		} catch (Exception e) {

			System.out.println("ERROR: "+e);

		
		}
        return result;

}
		
		public Flight getFlight(Flight flight){
			Flight f=null;
			try{
			EntityManagerFactory emf=Persistence.createEntityManagerFactory("puuu");
			EntityManager em=emf.createEntityManager();
			f=em.find(Flight.class, flight.getFlightid());
			
		}
			
		catch(Exception e){
			System.out.println("ERROR" +e);
		
		}
			return f;
	}
		


}