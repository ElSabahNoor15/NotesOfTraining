package com.jpaproject.app;

import java.util.Date;
import java.util.List;

import com.jpaproject.dao.Servicedao;
import com.jpaproject.model.Booking;
import com.jpaproject.model.Flight;
import com.jpaproject.model.Place;

public class TestApplication {

	public static void main(String[] args) {
		/*Place place=new Place();
		place.setPlaceid(1011);
		place.setLocation("DELHI");
		
		place.setPlacename("RED FORT");
		
		boolean flag=new Servicedao().addPlace(place);
		System.out.println(flag);*/
		
		/*Place place=new Place();
		place.setPlaceid(103);
		Place p= new Servicedao().getPlace(place);
		if(p==null){
			System.out.println("place not found");
			
		}
		else
			System.out.println(p.getPlacename());
			System.exit(0);*/
		
		/*Flight f =new Flight();
		f.setFlightid("300");
		f.setAirline("Indigo");
		f.setSource("Delhi");
		f.setDestination("Mumbai");
		
		
		Booking b1=new Booking();
		b1.setBookingdate(new Date());
	//	b1.setBookingid("10");
		b1.setPname("sana");
		
		Booking b2=new Booking();
		b2.setBookingdate(new Date());
		//b2.setBookingid("102");
		b2.setPname("sgcmh");
		
		f.getBookinglist().add(b1);
		f.getBookinglist().add(b2);
		boolean flag=new Servicedao().addFlight(f);
		
		System.out.println(flag);*/
		Flight ff = new Flight();
		ff.setFlightid("300");
		Flight f = new Servicedao().getFlight(ff);
		if (f!=null) {
			System.out.printf("\n%20s %20s",f.getSource(),f.getDestination());
			System.out.println("\n...........................");
			List<Booking> blist = f.getBookinglist();
			for(Booking b : blist)
			{
				System.out.printf("\n%20s %20s",b.getPname(),b.getPage());
			}
			
		}
		 
		
		
		System.exit(0);
		
	}
	

}
