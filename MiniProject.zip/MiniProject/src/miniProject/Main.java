package miniProject;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		// ImportTest.readCsv();

		 System.out.println("Complains you want to search according to options");
		 System.out.println("1. Search Bank");

		 System.out.println("2. Complaint Id");

		 System.out.println("3. Insert New Data");

		 System.out.println("4. Search Year");
		 Scanner sc = new Scanner(System.in);
		 int choice =Integer.parseInt(sc.nextLine());
		 
		 if(choice==1){
			 SearchBank.searchBank();
		 }
		 else
			 if(choice==2){
				 SearchComplainId.searchComplainId();
			 }
			 else
				 if(choice==3){
                     InsertNew.insertNew();
				 }
				 else
					 if(choice==4){
						 SearchYear.searchYear();
					 }
					 else
					 {
						 System.out.println("Thank you!!");
					 }

	}

}
