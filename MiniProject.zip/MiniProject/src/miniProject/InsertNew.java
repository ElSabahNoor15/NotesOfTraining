package miniProject;
import java.sql.*;
import java.util.Scanner;

public class InsertNew {

		public static void insertNew() {
			Connection connection=null;
			try 
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
				connection=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hr","hr");
				Scanner sc=new Scanner(System.in);
				System.out.println("Enter the Date Recieved");
				String a=sc.nextLine();
				System.out.println("Enter the PRODUCT");
				String b=sc.nextLine();
				System.out.println("Enter the SUB PRODUCT");
				String c=sc.nextLine();
				System.out.println("Enter the ISSUE");
				String d=sc.nextLine();
				System.out.println("Enter the SUB ISSUE");
				String e=sc.nextLine();
				System.out.println("Enter the company");
				String f=sc.nextLine();
				System.out.println("Enter the STATE");
				String g=sc.nextLine();
				System.out.println("Enter the ZIP CODE");
				String h=sc.nextLine();
				System.out.println("Enter SUBMITTED VIA");
				String i=sc.nextLine();
				System.out.println("Enter the DATE SENT TO COMPANY");
				String j=sc.nextLine();
				System.out.println("Enter the COMPANY RESPONSE TO CONSUMER");
				String k=sc.nextLine();
				System.out.println("Enter STATUS OF TIMELY RESPONSE?(YES/NO)");
				String l=sc.nextLine();
				System.out.println("STATUS OF CONSUMER DISPUTED?(YES/NO)");
				String m=sc.nextLine();
				System.out.println("Enter the COMPLAINT ID");
				String n=sc.nextLine();
				
				
				PreparedStatement smt=connection.prepareStatement("Insert into complaints values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
				
		smt.setString(1, a);
		smt.setString(2, b);
		smt.setString(3, c);
	smt.setString(4, d);
		smt.setString(5, e);
		smt.setString(6, f);
	smt.setString(7, g);
		smt.setString(8, h);
		smt.setString(9, i);
	smt.setString(10, j);
		smt.setString(11, k);
		smt.setString(12, l);
	smt.setString(13, m);
		smt.setString(14, n);

		

	smt.executeUpdate();
		System.out.println("data inserted");	
			}
			catch(ClassNotFoundException ce)
			{System.out.println(ce);}
			catch(Exception e) {System.out.println(e);}
			finally{
				try {
					connection.close();
					//smt.close();
				} catch (SQLException e) {
				
					e.printStackTrace();
				}
			}
			

		}

}
