package miniProject;
import java.io.FileReader;    
import java.sql.Connection;    
import java.sql.DriverManager;    
import java.sql.PreparedStatement;
import java.sql.Statement;
import au.com.bytecode.opencsv.CSVReader;

public class ImportTest {
   
    public static void readCsv() {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");

        Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe","hr","hr");
            PreparedStatement pstmt =conn.prepareStatement("Insert into complaints values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

            CSVReader reader = new CSVReader(new FileReader("D:\\complaints.csv"), ','); 
            String[] nextLine;
            //int i = 0;
            while((nextLine = reader.readNext()) != null) {
           //     i++;
                pstmt.setString(1,nextLine[0]);
                pstmt.setString(2,nextLine[1]);
                 pstmt.setString(3,nextLine[2]);
                pstmt.setString(4,nextLine[3]);
                pstmt.setString(5,nextLine[4]);
                pstmt.setString(6,nextLine[5]);
                pstmt.setString(7,nextLine[6]);
       		 pstmt.setString(8,nextLine[7]);
                pstmt.setString(9,nextLine[8]);
                pstmt.setString(10,nextLine[9]);
		 pstmt.setString(11,nextLine[10]);
		 pstmt.setString(12,nextLine[11]);
		 pstmt.setString(13,nextLine[12]);



		 pstmt.setString(14,nextLine[13]);
		 pstmt.execute();
            }

            pstmt.close();
            conn.commit();
            conn.close();
        } catch(Exception e) {
            e.printStackTrace();       
        }
    }
}