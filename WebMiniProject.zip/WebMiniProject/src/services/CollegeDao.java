package services;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import model.College;



public class CollegeDao {
	
	public List<College> getAllCollege(){
	      List<College> clist = new ArrayList<College>();
	      try {
	    	  Class.forName("oracle.jdbc.driver.OracleDriver");
				Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hr","hr");
				PreparedStatement smt = con.prepareStatement("select * from ProfessionalColleges");
				ResultSet rs = smt.executeQuery();
				while(rs.next())
				{
					College c = new College(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6));
					clist.add(c);
				}
				con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	      return clist;
		}
		
		public boolean registerCollege(College College)
		{
			boolean result = false;
			try {
				
				Class.forName("oracle.jdbc.driver.OracleDriver");
				Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hr","hr");
				PreparedStatement smt = con.prepareStatement("insert into ProfessionalColleges values(?,?,?,?,?,?)");
				smt.setString(1, College.getCid());
				smt.setString(2, College.getCname());
				smt.setString(3, College.getCoursetype());
				smt.setString(4, College.getCity());
				smt.setString(5, College.getFees());
				smt.setString(6, College.getPincode());
				int rs = smt.executeUpdate();
				
				con.close();
				if(rs>0) result=true;
				
				} catch (Exception e) {
				System.out.println(e);
			}
			
			
			return result;
		}
		
		public boolean removeCollege(String cid)
		{
			boolean result = false;
			try {
				
				Class.forName("oracle.jdbc.driver.OracleDriver");
				Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hr","hr");
				PreparedStatement smt = con.prepareStatement("delete from ProfessionalColleges where cid=?");
				smt.setString(1, cid);
				
				int rs = smt.executeUpdate();
				con.close();
				if(rs>0) result=true;
		}
			catch (Exception e) {
				System.out.println(e);
			}
			return result;
		}

	

}
