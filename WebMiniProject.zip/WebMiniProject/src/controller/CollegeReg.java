package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.College;
import services.CollegeDao;

public class CollegeReg extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public CollegeReg() {
        super();

    }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	
		
		String cid=request.getParameter("cid");
		String cname=request.getParameter("cname");
		String coursetype=request.getParameter("coursetype");
		String city=request.getParameter("city");
		String fees=request.getParameter("fees");
		String pincode=request.getParameter("pincode");
		
		
		College College = new College(cid, cname, coursetype, city, fees, pincode);
		boolean flag = new CollegeDao().registerCollege(College);
		if(flag)
		{
			RequestDispatcher rd = request.getRequestDispatcher("UserHome.jsp");
			request.setAttribute("msg", "College details is succesfully submitted");
			rd.forward(request, response);
		}
		else
		{
			RequestDispatcher rd = request.getRequestDispatcher("UserHome.jsp");
			request.setAttribute("msg", "Sorry ! College is not added");
			rd.forward(request, response);
		}
		
		


	}

}
