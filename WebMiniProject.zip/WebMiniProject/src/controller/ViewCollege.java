package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.College;
import services.CollegeDao;


public class ViewCollege extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ViewCollege() {
        super();
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		List<College> clist = new CollegeDao().getAllCollege();
		request.setAttribute("clist", clist);
		RequestDispatcher rd = request.getRequestDispatcher("ViewCollege.jsp");
		rd.forward(request, response);
		
	}

}
