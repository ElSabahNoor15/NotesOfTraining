package com.hiberproj1.dao;

import org.hibernate.Transaction;
import org.hibernate.engine.spi.SessionDelegatorBaseImpl;

import com.hiberproj1.model.Emp;
import com.hiberproj1.model.SessionModel;

import org.hibernate.Session;


public class ServiceDao {
public boolean addEmp(Emp e)
{
	boolean flag=false;
	try {
	Session session=new SessionModel().getSession();
	Transaction t = session.beginTransaction();
	session.save(e);
	t.commit();
	session.close();
	flag=true;
	} catch (Exception e2) {
		System.out.println("Error:" +e2);
	}
	return flag;
}	
public boolean editEmp(Emp e)
{
	boolean flag=false;
	try {
	Session session=new SessionModel().getSession();
	Transaction t = session.beginTransaction();
	session.update(e);
	t.commit();
	session.close();
	flag=true;
	} catch (Exception e2) {
		System.out.println("Error:" +e2);
	
	}
	return flag;
}	
public boolean deleteEmp(Emp e)
{
	boolean flag=false;
	try {
	Session session=new SessionModel().getSession();
	Transaction t = session.beginTransaction();
	session.delete(e);
	t.commit();
	session.close();
	flag=true;
	} catch (Exception e2) {
		System.out.println("Error:" +e2);
	
	}
	return flag;
}	
public Emp getEmp(Emp emp){
	Emp e= null;
	try {
		Session session=new SessionModel().getSession();
		e=(Emp)session.get(Emp.class, emp.getEno());
	
	
	} catch (Exception e2) {
		// TODO: handle exception
	}
	return e;
}
}
	


