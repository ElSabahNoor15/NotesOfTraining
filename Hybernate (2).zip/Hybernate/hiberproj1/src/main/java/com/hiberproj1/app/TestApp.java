package com.hiberproj1.app;


import com.hiberproj1.dao.ServiceDao;
import com.hiberproj1.model.Emp;

public class TestApp {

	public static void main(String[] args) {
/*Emp employee=new Emp();
employee.setEno(100);
employee.setEname("Ram");
employee.setSalary(12000);
System.out.println(new ServiceDao().editEmp(employee)); 
System.out.println(employee.getEname());*/	
		/*Emp employee=new Emp();
		employee.setEno(123);
		System.out.println(new ServiceDao().deleteEmp(employee));*/
		Emp employee=new Emp();
		employee.setEno(124);
		Emp e=new ServiceDao().getEmp(employee);
		if(e!=null){
			System.out.println(e.getEname());
		}
		else
			System.out.println("not found");
		
		
		
	}
}
