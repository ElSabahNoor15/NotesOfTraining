package com.hiberproj2.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="candidate")
public class Candidate {
	@Id
private int cid;
private String cname;
@Temporal(TemporalType.DATE)
private Date dob;
public int getCid() {
	return cid;
}
public void setCid(int cid) {
	this.cid = cid;
}
public String getCname() {
	return cname;
}
public void setCname(String cname) {
	this.cname = cname;
}
public Date getDob() {
	return dob;
}
public void setDob(Date dob) {
	this.dob = dob;
}
public Candidate(int cid, String cname, Date dob) {
	super();
	this.cid = cid;
	this.cname = cname;
	this.dob = dob;
}
public Candidate() {
	super();
}


}
