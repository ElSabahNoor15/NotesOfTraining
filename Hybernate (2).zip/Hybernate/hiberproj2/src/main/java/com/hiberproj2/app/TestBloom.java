package com.hiberproj2.app;

import com.hiberproj2.Dao.ServiceDao;
import com.hiberproj2.model.Candidate;
import com.hiberproj2.model.SessionModel;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import org.hibernate.sql.ordering.antlr.Factory;


public class TestBloom {

	public static void main(String[] args) {
		//Candidate candidate=new Candidate();
		/*Candidate.setCid(123);
		Candidate.setCname("Ram");
		Candidate.setDob("1990-01-19");
		System.out.println(new ServiceDao().editCandidate(Candidateloyee)); 
		System.out.println(Candidateloyee.getEname());*/	
				/*Candidate Candidateloyee=new Candidate();
				Candidateloyee.setEno(123);
				System.out.println(new ServiceDao().deleteCandidate(Candidateloyee));*/
		
	
        
		/*	Candidate can=new Candidate();
				can.setCid(125);
				can.setDob(new java.util.Date());
				Candidate c=new ServiceDao().getCandidate(can);
				if(c!=null){
					System.out.println(c.getCname());
					System.out.println(c.getDob());
				}
				else
					System.out.println("not found");*/
				
				List<Candidate> clist = new ServiceDao().searchAll();
				System.out.printf("\n%-10s %-10s %-10s","Cid","Cname","Dob");
				for(Candidate c:clist)
					System.out.printf("\n%-10s %-10s %-10s",c.getCid(),c.getCname(),c.getDob());
				
				
			}}
	


