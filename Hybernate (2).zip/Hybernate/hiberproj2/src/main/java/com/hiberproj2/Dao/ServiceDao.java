package com.hiberproj2.Dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.hiberproj2.model.Candidate;
import com.hiberproj2.model.SessionModel;

public class ServiceDao {
	/*public boolean editEmp(Candidate c)
	{
		boolean flag=false;
		try {
		Session session=new SessionModel().getSession();
		Transaction t = session.beginTransaction();
		session.update(c);
		t.commit();
		session.close();
		flag=true;
		} catch (Exception e2) {
			System.out.println("Error:" +e2);
		
		}
		return flag;
	}*/
		public Candidate getCandidate(Candidate c){
			Candidate ca= null;
			try {
				Session session=new SessionModel().getSession();
				ca=(Candidate)session.get(Candidate.class, c.getCid());
			
			
			} catch (Exception e2) {
				System.err.println(e2);
			}
			return ca;
}
		public List<Candidate>searchAll(){
			List<Candidate> candidatelist=null;
		Session session=new SessionModel().getSession();
		
		Query query = session.createQuery("from Candidate");
		
		candidatelist = query.list();
        return candidatelist;
		}
}