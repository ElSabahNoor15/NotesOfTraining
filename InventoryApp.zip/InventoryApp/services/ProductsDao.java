package services;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import model.Products;

public class ProductsDao {
	
	public List<Products> getAllProduct(){
      List<Products> plist = new ArrayList<Products>();
      try {
    	  Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hr","hr");
			PreparedStatement smt = con.prepareStatement("select * from product");
			ResultSet rs = smt.executeQuery();
			while(rs.next())
			{
				Products p = new Products(rs.getString(1),rs.getString(2),rs.getInt(3),rs.getInt(4),rs.getString(5));
				plist.add(p);
			}
			con.close();
	} catch (Exception e) {
		System.out.println(e);
	}
      return plist;
	}
	
	public boolean registerProduct(Products products)
	{
		boolean result = false;
		try {
			System.out.println("stock:"+ products.getStock());
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hr","hr");
			PreparedStatement smt = con.prepareStatement("insert into product values(?,?,?,?,?)");
			smt.setString(1, products.getPid());
			smt.setString(2, products.getPname());
			smt.setInt(3, products.getUnitprice());
			smt.setInt(4, products.getStock());
			smt.setString(5, products.getCategory());
			int rs = smt.executeUpdate();
			
			con.close();
			if(rs>0) result=true;
			
			} catch (Exception e) {
			System.out.println(e);
		}
		
		
		return result;
	}

}
