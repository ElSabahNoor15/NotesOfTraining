package controler;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Products;
import services.ProductsDao;

@WebServlet("/ProductRegister")
public class ProductRegister extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public ProductRegister() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      
		String pid=request.getParameter("pid");
		String pname=request.getParameter("pname");
		String unitprice=request.getParameter("unitprice");
		String stock=request.getParameter("stock");
		String category=request.getParameter("category");
		System.out.println("st="+stock);
		Products products = new Products(pid, pname, Integer.parseInt(unitprice), Integer.parseInt(stock), category);
		boolean flag = new ProductsDao().registerProduct(products);
		if(flag)
		{
			RequestDispatcher rd = request.getRequestDispatcher("UserHome.jsp");
			request.setAttribute("msg", "Product is succesfully submitted");
			rd.forward(request, response);
		}
		else
		{
			RequestDispatcher rd = request.getRequestDispatcher("UserHome.jsp");
			request.setAttribute("msg", "Sorry ! Product is not added");
			rd.forward(request, response);
		}
		
		
	}

}
