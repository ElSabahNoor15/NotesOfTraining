package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.User;
import services.UserDao;

public class URegister extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public URegister() {
        super();
        
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String uid=request.getParameter("uid");
		String name=request.getParameter("name");
		String pwd=request.getParameter("pwd");
		String age=request.getParameter("age");
		
		User u = new User(uid, pwd, name, age);
		boolean flag = new UserDao().addUser(u);
		if(flag) {
			response.sendRedirect("Register.jsp");
		}
		else {
			response.sendRedirect("index.jsp");
		}
	}

}
