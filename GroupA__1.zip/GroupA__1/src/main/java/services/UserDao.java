package services;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import model.User;



public class UserDao {
	
	public boolean addUser(User User) {
		boolean result = false;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:xe",
					"hr",
					"hr"); 
			PreparedStatement smt = con.prepareStatement("insert into User_master values(?,?,?,?)");
			
		  smt.setString(1,  User.getUid());
		  smt.setString(2,  User.getPwd());
		  smt.setString(3,  User.getName());
		  smt.setString(4,  User.getAge());
		 
		  int rs=smt.executeUpdate();
		  con.close();
		  if(rs>0) 
			  result=true;
		}
		catch(Exception e){ 
			System.out.println(e);
		}
		return result;
		
	

}}
