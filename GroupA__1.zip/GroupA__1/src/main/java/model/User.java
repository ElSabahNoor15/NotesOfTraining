package model;

public class User {
	private String uid;
	private String pwd;
	private String name;
	private String age;
	
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public User(String uid, String pwd, String name, String age) {
		super();
		this.uid = uid;
		this.pwd = pwd;
		this.name = name;
		this.age = age;
	}
	public User() {
		super();
	}
	

}
