package service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.Track;


public class MyService 
	{
	public List<Track> getAllTracks(){
	      List<Track> tlist = new ArrayList<Track>();
	      try {
	    	  Class.forName("oracle.jdbc.driver.OracleDriver");
				Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hr","hr");
				PreparedStatement smt = con.prepareStatement("select * from track");
				ResultSet rs = smt.executeQuery();
				while(rs.next())
				{
					Track t = new Track(rs.getString(1), rs.getString(2));
					tlist.add(t);
				}
				con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	      return tlist;
		}
		
	
	public Track getTrack(String title){
		Track track=null;
	     System.out.println("title:"+title);
	      try {
	    	  Class.forName("oracle.jdbc.driver.OracleDriver");
				Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hr","hr");
				PreparedStatement smt = con.prepareStatement("select * from track where title=?");
				smt.setString(1,title);
				ResultSet  rs = smt.executeQuery();
				if(rs.next())
				{
					track = new Track(rs.getString(1), rs.getString(2));
					
				}
				con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	      System.out.println(track);
	      return track;
		}
	//put track
	public boolean addTrack(Track track)
	{
		boolean result = false;
		try {
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hr","hr");
			PreparedStatement smt = con.prepareStatement("insert into track values(?,?)");
			smt.setString(1, track.getTitle());
			smt.setString(2, track.getSinger());
			int rs = smt.executeUpdate();
			
			con.close();
			if(rs>0) result=true;
			
			} catch (Exception e) {
			System.out.println(e);
		}
		
		
		return result;
	}
	public boolean removeTrack(String title)
	{
		boolean result = false;
		try {
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hr","hr");
			PreparedStatement smt = con.prepareStatement("delete from track where title=?");
			smt.setString(1, title);
			
			int rs = smt.executeUpdate();
			con.close();
			if(rs>0) result=true;
	}
		catch (Exception e) {
			System.out.println(e);
		}
		return result;
	}
	public boolean updateTrack(Track track)
	{
		boolean result = false;
		try {
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hr","hr");
			PreparedStatement smt = con.prepareStatement("update track set tilte=? where singer=?");
			smt.setString(1, track.getTitle());
			smt.setString(2, track.getSinger());
			int rs = smt.executeUpdate();
			
			con.close();
			if(rs>0) result=true;
			
			} catch (Exception e) {
			System.out.println(e);
		}
		
		
		return result;
	}
	
	
	}
